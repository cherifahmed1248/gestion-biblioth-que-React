export default [

    {
        "id": 21,
        "title": "Livre 21",
        "libelle": "Vous rêvez d'apprendre à créer des sites web mais vous avez peur que ce soit compliqué car vous débutez ? Ce livre est fait pour vous ! Conçu pour les débutants, il vous permettra de découvrir HTML 5 et CSS 3, les dernières technologies en matière de création de sites web, de façon progressive et sans aucun prérequis, si ce n'est de savoir allumer son ordinateur !",
        "prix": "18,99",
        "auteur": "Ahmed",
        "edition": "2 EDITION",
        "exemplaire": "3",
        "archive": "false"
    },
    {
        "id": 22,
        "title": "Livre 22",
        "libelle": "Vous rêvez d'apprendre à créer des sites web mais vous avez peur que ce soit compliqué car vous débutez ? Ce livre est fait pour vous ! Conçu pour les débutants, il vous permettra de découvrir HTML 5 et CSS 3, les dernières technologies en matière de création de sites web, de façon progressive et sans aucun prérequis, si ce n'est de savoir allumer son ordinateur !",
        "prix": "18,99",
        "auteur": "Mathieu Nebra",
        "edition": "2 EDITION",
        "exemplaire": "133",
        "archive": "false"
    },
    {
        "id": 31,
        "title": "Livre 31",
        "libelle": "Vous rêvez d'apprendre à créer des sites web mais vous avez peur que ce soit compliqué car vous débutez ? Ce livre est fait pour vous ! Conçu pour les débutants, il vous permettra de découvrir HTML 5 et CSS 3, les dernières technologies en matière de création de sites web, de façon progressive et sans aucun prérequis, si ce n'est de savoir allumer son ordinateur !",
        "prix": "18,99",
        "auteur": "Mathieu Nebra",
        "edition": "2 EDITION",
        "exemplaire": "133",
        "archive": "false"
    },
    {
        "id": 32,
        "title": "Livre 32",
        "libelle": "Vous rêvez d'apprendre à créer des sites web mais vous avez peur que ce soit compliqué car vous débutez ? Ce livre est fait pour vous ! Conçu pour les débutants, il vous permettra de découvrir HTML 5 et CSS 3, les dernières technologies en matière de création de sites web, de façon progressive et sans aucun prérequis, si ce n'est de savoir allumer son ordinateur !",
        "prix": "18,99",
        "auteur": "Mathieu Nebra",
        "edition": "2 EDITION",
        "exemplaire": "133",
        "archive": "false"
    }
]